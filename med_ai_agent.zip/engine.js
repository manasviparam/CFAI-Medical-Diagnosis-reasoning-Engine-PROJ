const SYNONYMS = {
  // Fatigue
  "tired": "fatigue", "tiredness": "fatigue", "exhausted": "fatigue",
  "no energy": "fatigue", "lethargic": "fatigue", "lethargy": "fatigue",
  "worn out": "fatigue", "run down": "fatigue", "sluggish": "fatigue",
  "drained": "fatigue", "weak": "fatigue", "weakness": "fatigue",
  "no strength": "fatigue", "wiped out": "fatigue", "burnt out": "fatigue",

  // Vomiting
  "throwing up": "vomiting", "threw up": "vomiting", "puked": "vomiting",
  "sick to stomach": "vomiting", "puke": "vomiting", "puking": "vomiting",
  "vomit": "vomiting", "retching": "vomiting", "heaving": "vomiting",
  "tossed cookies": "vomiting",

  // Difficulty breathing
  "cant breathe": "difficulty_breathing", "can't breathe": "difficulty_breathing",
  "shortness of breath": "difficulty_breathing", "breathless": "difficulty_breathing",
  "short of breath": "difficulty_breathing", "hard to breathe": "difficulty_breathing",
  "trouble breathing": "difficulty_breathing", "labored breathing": "difficulty_breathing",
  "winded": "difficulty_breathing", "gasping": "difficulty_breathing",
  "cant catch my breath": "difficulty_breathing", "wheezing": "difficulty_breathing",
  "wheeze": "difficulty_breathing",

  // Runny nose
  "stuffy nose": "runny_nose", "blocked nose": "runny_nose", "congestion": "runny_nose",
  "stuffed up": "runny_nose", "nasal congestion": "runny_nose", "runny nose": "runny_nose",
  "dripping nose": "runny_nose", "postnasal drip": "runny_nose",

  // Fever
  "temp": "fever", "temperature": "fever", "hot": "fever", "burning up": "fever",
  "running a fever": "fever", "high temp": "fever", "high temperature": "fever",
  "febrile": "fever", "pyrexia": "fever", "feverish": "fever",

  // Body aches
  "ache": "body_aches", "aching": "body_aches", "sore muscles": "body_aches",
  "muscle pain": "body_aches", "body pain": "body_aches", "myalgia": "body_aches",
  "muscle ache": "body_aches", "muscles hurt": "body_aches", "hurting all over": "body_aches",
  "all over pain": "body_aches",

  // Abdominal pain
  "stomach ache": "abdominal_pain", "tummy ache": "abdominal_pain",
  "belly pain": "abdominal_pain", "gut pain": "abdominal_pain",
  "stomach pain": "abdominal_pain", "stomach cramps": "abdominal_pain",
  "cramps": "abdominal_pain", "abdominal cramps": "abdominal_pain",
  "belly ache": "abdominal_pain", "tummy pain": "abdominal_pain",

  // Palpitations
  "heart racing": "palpitations", "racing heart": "palpitations",
  "fast heartbeat": "palpitations", "fluttering": "palpitations",
  "heart pounding": "palpitations", "pounding heart": "palpitations",
  "heart skipping": "palpitations", "irregular heartbeat": "palpitations",
  "rapid heart": "palpitations", "tachycardia": "palpitations",

  // Loss of taste/smell
  "cant taste": "loss_of_taste_smell", "can't taste": "loss_of_taste_smell",
  "no taste": "loss_of_taste_smell", "no smell": "loss_of_taste_smell",
  "lost smell": "loss_of_taste_smell", "lost taste": "loss_of_taste_smell",
  "anosmia": "loss_of_taste_smell", "ageusia": "loss_of_taste_smell",
  "cant smell": "loss_of_taste_smell", "can't smell": "loss_of_taste_smell",

  // Sweating
  "sweating": "sweating", "sweaty": "sweating", "drenched": "sweating",
  "perspiring": "sweating", "perspiration": "sweating", "night sweats": "night_sweats",
  "clammy": "sweating",

  // Blurred vision
  "blurry": "blurred_vision", "blurry vision": "blurred_vision",
  "cant see clearly": "blurred_vision", "foggy vision": "blurred_vision",
  "can't see clearly": "blurred_vision", "vision blurry": "blurred_vision",
  "double vision": "blurred_vision", "vision problems": "blurred_vision",

  // Dizziness
  "dizzy": "dizziness", "lightheaded": "dizziness", "spinning": "dizziness",
  "vertigo": "dizziness", "off balance": "dizziness", "unsteady": "dizziness",
  "woozy": "dizziness", "lightheadedness": "dizziness", "giddiness": "dizziness",

  // Joint pain
  "stiff joints": "joint_pain", "swollen joints": "joint_pain",
  "joint swelling": "joint_pain", "achy joints": "joint_pain",
  "joints hurt": "joint_pain", "arthralgia": "joint_pain",

  // Rash
  "bumps": "rash", "spots": "rash", "hives": "rash",
  "skin reaction": "rash", "welts": "rash", "breakout": "rash",
  "skin rash": "rash", "eruption": "rash",

  // Itching
  "scratching": "itching", "itchy": "itching", "itchy skin": "itching",
  "pruritus": "itching", "itch": "itching",

  // Frequent urination
  "peeing a lot": "frequent_urination", "urinating frequently": "frequent_urination",
  "bathroom a lot": "frequent_urination", "urinary frequency": "frequent_urination",
  "frequent peeing": "frequent_urination", "pee a lot": "frequent_urination",
  "dysuria": "frequent_urination",

  // Numbness
  "pins and needles": "numbness", "tingling": "numbness", "numb": "numbness",
  "cant feel": "numbness", "can't feel": "numbness", "paresthesia": "numbness",
  "loss of sensation": "numbness",

  // Weight loss
  "losing weight": "weight_loss", "weight dropping": "weight_loss",
  "not eating": "weight_loss", "losing appetite": "loss_of_appetite",
  "unintentional weight loss": "weight_loss",

  // Chest pain
  "chest tightness": "chest_pain", "pressure in chest": "chest_pain",
  "chest heaviness": "chest_pain", "chest pressure": "chest_pain",
  "tight chest": "chest_pain", "chest discomfort": "chest_pain",
  "angina": "chest_pain",

  // Emergency flag
  "coughing up blood": "EMERGENCY_FLAG", "blood in cough": "EMERGENCY_FLAG",
  "coughing blood": "EMERGENCY_FLAG", "hemoptysis": "EMERGENCY_FLAG",
  "vomiting blood": "EMERGENCY_FLAG", "blood in vomit": "EMERGENCY_FLAG",
  "chest pain radiating arm": "EMERGENCY_FLAG",

  // Cough
  "coughing": "cough", "coughs": "cough", "dry cough": "cough",
  "persistent cough": "cough", "productive cough": "cough",

  // Fever extra
  "chills": "chills", "shivering": "chills", "rigors": "chills",
  "shaking": "chills",

  // Headache
  "headache": "headache", "head pain": "headache", "migraine": "headache",
  "head hurts": "headache", "cephalgia": "headache",

  // Sore throat
  "sore throat": "sore_throat", "throat pain": "sore_throat",
  "throat hurts": "sore_throat", "painful swallowing": "sore_throat",
  "pharyngitis": "sore_throat", "tonsillitis": "sore_throat",

  // Nausea
  "nauseous": "nausea", "queasy": "nausea", "feel like vomiting": "nausea",
  "upset stomach": "nausea", "feel sick": "nausea",

  // Diarrhea
  "diarrhea": "diarrhea", "loose stools": "diarrhea", "watery stool": "diarrhea",
  "runs": "diarrhea", "loose bowels": "diarrhea",

  // Back pain
  "back pain": "back_pain", "backache": "back_pain", "back hurts": "back_pain",
  "lower back pain": "back_pain", "lumbar pain": "back_pain",

  // Swollen lymph nodes
  "swollen glands": "swollen_lymph_nodes", "lymph nodes": "swollen_lymph_nodes",
  "glands swollen": "swollen_lymph_nodes", "swollen neck": "swollen_lymph_nodes",

  // Night sweats
  "wake up sweating": "night_sweats", "sweating at night": "night_sweats",
  "nocturnal sweating": "night_sweats",

  // Sneezing
  "sneeze": "sneezing", "sneezing": "sneezing", "sneezes": "sneezing",

  // Loss of appetite
  "no appetite": "loss_of_appetite", "not hungry": "loss_of_appetite",
  "loss of appetite": "loss_of_appetite", "anorexia": "loss_of_appetite"
};

function parseFreText(text) {
  if (!text || typeof text !== "string") {
    return { matched: {}, unknown: [], emergency: false };
  }

  const normalizedText = text.toLowerCase().replace(/[^\w\s]/g, " ");
  const tokens = normalizedText.split(/\s+/).filter(Boolean);
  const matched = {};
  const usedIndices = new Set();
  let emergency = false;

  // Try multi-word phrases up to 4 tokens
  for (let windowSize = 4; windowSize >= 1; windowSize--) {
    for (let i = 0; i <= tokens.length - windowSize; i++) {
      // Check if any token in window already used
      let alreadyUsed = false;
      for (let k = i; k < i + windowSize; k++) {
        if (usedIndices.has(k)) { alreadyUsed = true; break; }
      }
      if (alreadyUsed) continue;

      const phrase = tokens.slice(i, i + windowSize).join(" ");
      if (SYNONYMS.hasOwnProperty(phrase)) {
        const mapped = SYNONYMS[phrase];
        if (mapped === "EMERGENCY_FLAG") {
          emergency = true;
        } else {
          matched[mapped] = true;
        }
        for (let k = i; k < i + windowSize; k++) usedIndices.add(k);
      }
    }
  }

  // Collect unknown tokens
  const unknown = [];
  const medicalNoise = new Set([
    "i", "me", "my", "have", "has", "had", "am", "is", "are", "was",
    "been", "feel", "feeling", "some", "bit", "little", "really", "very",
    "and", "or", "but", "the", "a", "an", "in", "on", "at", "to", "of",
    "with", "for", "its", "it", "also", "since", "days", "weeks", "bad",
    "quite", "experiencing", "getting", "got", "lot", "lots", "severe"
  ]);

  for (let i = 0; i < tokens.length; i++) {
    if (!usedIndices.has(i) && tokens[i].length > 2 && !medicalNoise.has(tokens[i])) {
      unknown.push(tokens[i]);
    }
  }

  return { matched, unknown, emergency };
}

function classifyBP(systolic, diastolic) {
  if (systolic < 90 || diastolic < 60) return "Low";
  if (systolic <= 120 && diastolic <= 80) return "Normal";
  if (systolic <= 139 || diastolic <= 89) return "Elevated";
  return "High";
}

function classifyCholesterol(mgdl) {
  if (mgdl < 150) return "Low";
  if (mgdl < 200) return "Normal";
  if (mgdl < 240) return "Elevated";
  return "High";
}

function ageGaussian(age, mean, std) {
  const effectiveStd = Math.max(std, 5);
  const exponent = -0.5 * Math.pow((age - mean) / effectiveStd, 2);
  const density = Math.exp(exponent) / (effectiveStd * Math.sqrt(2 * Math.PI));
  return Math.max(density, 0.05);
}

function diagnose(inputs) {
  const {
    age,
    bp,
    cholesterol,
    bp_confidence = 1.0,
    chol_confidence = 1.0,
    symptoms = {},
    preexisting = [],
    unknown_symptom_count = 0
  } = inputs;

  const results = [];
  let totalScore = 0;

  // First pass: compute raw scores
  for (const disease of DISEASES) {
    let score = disease.prior;
    const trace = [{ label: "Prior", value: disease.prior }];

    // Symptom likelihoods
    const allSymptomKeys = Object.keys(disease.symptoms);
    for (const key of allSymptomKeys) {
      const pSymGivenDisease = disease.symptoms[key];
      const present = symptoms[key] === true;
      const absent = symptoms[key] === false;

      if (present) {
        score *= pSymGivenDisease;
        trace.push({ label: "+" + key.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()), value: score });
      } else if (absent) {
        score *= (1 - pSymGivenDisease);
      }
    }

    // Blood pressure modifier
    let bpCategory = bp || "Unknown";
    const bpMod = disease.bp_modifier[bpCategory] !== undefined
      ? disease.bp_modifier[bpCategory]
      : 1.0;
    // Apply confidence-weighted modifier
    const effectiveBpMod = 1.0 + (bpMod - 1.0) * (bp_confidence || 1.0);
    score *= effectiveBpMod;
    trace.push({ label: "+Blood Pressure", value: score });

    // Cholesterol modifier
    let cholCategory = cholesterol || "Unknown";
    const cholMod = disease.cholesterol_modifier[cholCategory] !== undefined
      ? disease.cholesterol_modifier[cholCategory]
      : 1.0;
    const effectiveCholMod = 1.0 + (cholMod - 1.0) * (chol_confidence || 1.0);
    score *= effectiveCholMod;
    trace.push({ label: "+Cholesterol", value: score });

    // Age factor
    let ageFactor = 1.0;
    if (age != null && !isNaN(age)) {
      ageFactor = ageGaussian(age, disease.age_mean, disease.age_std);
      score *= ageFactor;
    }
    trace.push({ label: "+Age", value: score });

    // Preexisting conditions
    if (preexisting && preexisting.length > 0) {
      for (const condition of preexisting) {
        if (disease.preexisting_modifiers && disease.preexisting_modifiers[condition] != null) {
          score *= disease.preexisting_modifiers[condition];
        }
      }
    }
    trace.push({ label: "+Pre-existing", value: score });

    // Check emergency symptoms
    const emergency_triggered = disease.emergency_symptoms.some(
      sym => symptoms[sym] === true
    );

    results.push({
      disease,
      raw_score: score,
      belief_trace: trace,
      danger_level: disease.danger_level,
      emergency_triggered
    });

    totalScore += score;
  }

  // Normalize and compute relative traces
  for (const r of results) {
    r.probability = totalScore > 0 ? (r.raw_score / totalScore) * 100 : 0;

    // Normalize trace values to running relative probabilities
    r.belief_trace = r.belief_trace.map(entry => ({
      label: entry.label,
      value: totalScore > 0 ? (entry.value / totalScore) * 100 : 0
    }));

    // Add final normalized entry
    r.belief_trace.push({ label: "Final (normalized)", value: r.probability });
  }

  results.sort((a, b) => b.probability - a.probability);
  return results;
}

function checkEmergency(inputs, topResult) {
  const { symptoms = {}, emergency_flag = false } = inputs;

  // Emergency flag from free text (e.g. coughing blood)
  if (emergency_flag) return true;

  // Emergency symptoms for the top-ranked disease
  if (topResult && topResult.disease && topResult.disease.emergency_symptoms) {
    for (const sym of topResult.disease.emergency_symptoms) {
      if (symptoms[sym] === true) return true;
    }
  }

  // Dangerous symptom combinations
  if (symptoms["chest_pain"] && symptoms["body_aches"]) return true; // possible heart attack
  if (symptoms["numbness"] && symptoms["blurred_vision"] && symptoms["headache"]) return true; // possible stroke
  if (symptoms["difficulty_breathing"] && symptoms["chest_pain"]) return true; // possible PE or severe asthma

  return false;
}
