const DISEASES = [
  {
    name: "Influenza",
    prior: 0.08,
    description: "A contagious respiratory illness caused by influenza viruses affecting the nose, throat, and lungs.",
    see_doctor_if: "Seek care immediately if you experience difficulty breathing, persistent chest pain, confusion, or severe vomiting.",
    danger_level: "medium",
    emergency_symptoms: ["difficulty_breathing", "chest_pain"],
    key_symptoms: ["fever", "body_aches", "fatigue", "cough", "chills"],
    age_mean: 35,
    age_std: 25,
    symptoms: {
      fever: 0.87, cough: 0.80, fatigue: 0.85, difficulty_breathing: 0.20,
      headache: 0.70, nausea: 0.30, vomiting: 0.20, diarrhea: 0.15,
      chest_pain: 0.10, sore_throat: 0.50, runny_nose: 0.45, body_aches: 0.85,
      chills: 0.80, loss_of_appetite: 0.60, sweating: 0.65, dizziness: 0.30,
      rash: 0.02, joint_pain: 0.40, abdominal_pain: 0.10, back_pain: 0.30,
      swollen_lymph_nodes: 0.15, frequent_urination: 0.02, blurred_vision: 0.05,
      numbness: 0.02, weight_loss: 0.10, night_sweats: 0.30, sneezing: 0.40,
      itching: 0.02, palpitations: 0.08, loss_of_taste_smell: 0.20
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.9, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Asthma": 1.3, "COPD": 1.4, "Diabetes": 1.2, "Heart Disease": 1.3, "Immunocompromised": 1.8
    }
  },
  {
    name: "Common Cold",
    prior: 0.12,
    description: "A mild viral infection of the upper respiratory tract causing runny nose, sore throat, and sneezing.",
    see_doctor_if: "See a doctor if symptoms last more than 10 days, fever exceeds 103°F, or symptoms suddenly worsen.",
    danger_level: "low",
    emergency_symptoms: [],
    key_symptoms: ["runny_nose", "sneezing", "sore_throat", "cough"],
    age_mean: 25,
    age_std: 20,
    symptoms: {
      fever: 0.35, cough: 0.70, fatigue: 0.55, difficulty_breathing: 0.05,
      headache: 0.45, nausea: 0.10, vomiting: 0.05, diarrhea: 0.05,
      chest_pain: 0.02, sore_throat: 0.75, runny_nose: 0.90, body_aches: 0.35,
      chills: 0.20, loss_of_appetite: 0.30, sweating: 0.15, dizziness: 0.10,
      rash: 0.01, joint_pain: 0.10, abdominal_pain: 0.05, back_pain: 0.10,
      swollen_lymph_nodes: 0.20, frequent_urination: 0.01, blurred_vision: 0.02,
      numbness: 0.01, weight_loss: 0.05, night_sweats: 0.05, sneezing: 0.85,
      itching: 0.02, palpitations: 0.02, loss_of_taste_smell: 0.15
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {}
  },
  {
    name: "Pneumonia",
    prior: 0.04,
    description: "A serious lung infection that inflames the air sacs, potentially filling them with fluid or pus.",
    see_doctor_if: "Go to the ER immediately if you have severe difficulty breathing, bluish lips, chest pain, or high fever with confusion.",
    danger_level: "high",
    emergency_symptoms: ["difficulty_breathing", "chest_pain", "fever"],
    key_symptoms: ["fever", "cough", "difficulty_breathing", "fatigue", "chest_pain"],
    age_mean: 55,
    age_std: 25,
    symptoms: {
      fever: 0.90, cough: 0.90, fatigue: 0.80, difficulty_breathing: 0.70,
      headache: 0.30, nausea: 0.30, vomiting: 0.20, diarrhea: 0.15,
      chest_pain: 0.55, sore_throat: 0.20, runny_nose: 0.15, body_aches: 0.55,
      chills: 0.75, loss_of_appetite: 0.60, sweating: 0.65, dizziness: 0.30,
      rash: 0.02, joint_pain: 0.15, abdominal_pain: 0.20, back_pain: 0.25,
      swollen_lymph_nodes: 0.20, frequent_urination: 0.02, blurred_vision: 0.05,
      numbness: 0.02, weight_loss: 0.25, night_sweats: 0.45, sneezing: 0.10,
      itching: 0.02, palpitations: 0.15, loss_of_taste_smell: 0.10
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Diabetes": 1.5, "COPD": 1.8, "Heart Disease": 1.4, "Immunocompromised": 2.0, "Asthma": 1.3
    }
  },
  {
    name: "Parainfluenza",
    prior: 0.06,
    description: "A common respiratory infection caused by human parainfluenza viruses (HPIV), leading to croup, bronchiolitis, and flu-like illness especially in children and immunocompromised individuals.",
    see_doctor_if: "See a doctor if breathing becomes difficult, croup worsens at night, symptoms persist beyond 10 days, or a high fever develops in young children.",
    danger_level: "moderate",
    emergency_symptoms: ["difficulty_breathing", "chest_pain"],
    key_symptoms: ["fever", "cough", "sore_throat", "runny_nose", "fatigue"],
    age_mean: 20,
    age_std: 18,
    symptoms: {
      fever: 0.72, cough: 0.82, fatigue: 0.75, difficulty_breathing: 0.35,
      headache: 0.50, nausea: 0.20, vomiting: 0.15, diarrhea: 0.15,
      chest_pain: 0.20, sore_throat: 0.70, runny_nose: 0.75, body_aches: 0.55,
      chills: 0.50, loss_of_appetite: 0.50, sweating: 0.35, dizziness: 0.25,
      rash: 0.05, joint_pain: 0.20, abdominal_pain: 0.15, back_pain: 0.25,
      swollen_lymph_nodes: 0.30, frequent_urination: 0.02, blurred_vision: 0.05,
      numbness: 0.05, weight_loss: 0.15, night_sweats: 0.20, sneezing: 0.55,
      itching: 0.04, palpitations: 0.10, loss_of_taste_smell: 0.20
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.9, "Normal": 1.0, "Elevated": 1.1, "High": 1.2 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    preexisting_modifiers: {
      "Asthma": 1.6, "COPD": 1.7, "Immunocompromised": 2.0, "Heart Disease": 1.3
    }
  },
  {
    name: "Bronchitis",
    prior: 0.05,
    description: "Inflammation of the bronchial tubes causing a persistent cough, often with mucus production.",
    see_doctor_if: "See a doctor if cough lasts more than 3 weeks, you cough up blood, or have a high fever.",
    danger_level: "low",
    emergency_symptoms: ["difficulty_breathing"],
    key_symptoms: ["cough", "fatigue", "chest_pain", "difficulty_breathing"],
    age_mean: 40,
    age_std: 20,
    symptoms: {
      fever: 0.30, cough: 0.95, fatigue: 0.60, difficulty_breathing: 0.35,
      headache: 0.20, nausea: 0.10, vomiting: 0.05, diarrhea: 0.05,
      chest_pain: 0.40, sore_throat: 0.30, runny_nose: 0.30, body_aches: 0.30,
      chills: 0.20, loss_of_appetite: 0.25, sweating: 0.20, dizziness: 0.10,
      rash: 0.01, joint_pain: 0.05, abdominal_pain: 0.05, back_pain: 0.15,
      swollen_lymph_nodes: 0.10, frequent_urination: 0.01, blurred_vision: 0.02,
      numbness: 0.01, weight_loss: 0.10, night_sweats: 0.10, sneezing: 0.20,
      itching: 0.02, palpitations: 0.05, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Asthma": 1.5, "COPD": 1.8, "Smoking": 2.0
    }
  },
  {
    name: "Asthma",
    prior: 0.04,
    description: "A chronic condition causing airway inflammation and narrowing, leading to wheezing and breathing difficulty.",
    see_doctor_if: "Call 911 immediately if you cannot speak in full sentences, lips turn blue, or your rescue inhaler provides no relief.",
    danger_level: "high",
    emergency_symptoms: ["difficulty_breathing", "chest_pain"],
    key_symptoms: ["difficulty_breathing", "cough", "chest_pain", "fatigue"],
    age_mean: 25,
    age_std: 20,
    symptoms: {
      fever: 0.10, cough: 0.85, fatigue: 0.55, difficulty_breathing: 0.90,
      headache: 0.15, nausea: 0.10, vomiting: 0.05, diarrhea: 0.03,
      chest_pain: 0.60, sore_throat: 0.15, runny_nose: 0.25, body_aches: 0.10,
      chills: 0.05, loss_of_appetite: 0.15, sweating: 0.20, dizziness: 0.20,
      rash: 0.05, joint_pain: 0.05, abdominal_pain: 0.05, back_pain: 0.10,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.01, blurred_vision: 0.05,
      numbness: 0.02, weight_loss: 0.05, night_sweats: 0.10, sneezing: 0.30,
      itching: 0.15, palpitations: 0.15, loss_of_taste_smell: 0.03
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Allergic Rhinitis": 1.4, "Eczema": 1.3, "Obesity": 1.3
    }
  },
  {
    name: "Allergic Rhinitis",
    prior: 0.06,
    description: "An allergic response causing cold-like symptoms such as sneezing, runny nose, and itchy eyes.",
    see_doctor_if: "See a doctor if symptoms significantly impair sleep or daily function, or if you develop wheezing or shortness of breath.",
    danger_level: "low",
    emergency_symptoms: [],
    key_symptoms: ["sneezing", "runny_nose", "itching", "headache"],
    age_mean: 25,
    age_std: 15,
    symptoms: {
      fever: 0.05, cough: 0.40, fatigue: 0.45, difficulty_breathing: 0.15,
      headache: 0.50, nausea: 0.05, vomiting: 0.02, diarrhea: 0.02,
      chest_pain: 0.02, sore_throat: 0.25, runny_nose: 0.90, body_aches: 0.05,
      chills: 0.02, loss_of_appetite: 0.10, sweating: 0.02, dizziness: 0.10,
      rash: 0.10, joint_pain: 0.02, abdominal_pain: 0.02, back_pain: 0.02,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.01, blurred_vision: 0.05,
      numbness: 0.01, weight_loss: 0.02, night_sweats: 0.02, sneezing: 0.92,
      itching: 0.70, palpitations: 0.02, loss_of_taste_smell: 0.30
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Asthma": 1.5, "Eczema": 1.4
    }
  },
  {
    name: "Sinusitis",
    prior: 0.05,
    description: "Inflammation of the sinuses causing facial pain, nasal congestion, and thick nasal discharge.",
    see_doctor_if: "See a doctor if you have severe headache, stiff neck, vision changes, or symptoms persisting more than 10 days.",
    danger_level: "low",
    emergency_symptoms: ["headache"],
    key_symptoms: ["headache", "runny_nose", "fatigue", "cough", "sore_throat"],
    age_mean: 35,
    age_std: 18,
    symptoms: {
      fever: 0.40, cough: 0.50, fatigue: 0.55, difficulty_breathing: 0.20,
      headache: 0.80, nausea: 0.15, vomiting: 0.05, diarrhea: 0.03,
      chest_pain: 0.02, sore_throat: 0.45, runny_nose: 0.85, body_aches: 0.30,
      chills: 0.20, loss_of_appetite: 0.25, sweating: 0.15, dizziness: 0.25,
      rash: 0.01, joint_pain: 0.05, abdominal_pain: 0.02, back_pain: 0.10,
      swollen_lymph_nodes: 0.25, frequent_urination: 0.01, blurred_vision: 0.05,
      numbness: 0.02, weight_loss: 0.05, night_sweats: 0.05, sneezing: 0.60,
      itching: 0.10, palpitations: 0.02, loss_of_taste_smell: 0.40
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Allergic Rhinitis": 1.5, "Asthma": 1.2
    }
  },
  {
    name: "Tuberculosis",
    prior: 0.02,
    description: "A serious bacterial infection primarily affecting the lungs, spread through airborne droplets.",
    see_doctor_if: "Seek immediate care if you cough up blood, have severe breathing difficulty, or unexplained significant weight loss.",
    danger_level: "high",
    emergency_symptoms: ["cough", "weight_loss", "night_sweats"],
    key_symptoms: ["cough", "night_sweats", "weight_loss", "fatigue", "fever"],
    age_mean: 40,
    age_std: 20,
    symptoms: {
      fever: 0.65, cough: 0.90, fatigue: 0.85, difficulty_breathing: 0.45,
      headache: 0.20, nausea: 0.15, vomiting: 0.10, diarrhea: 0.10,
      chest_pain: 0.40, sore_throat: 0.10, runny_nose: 0.05, body_aches: 0.45,
      chills: 0.40, loss_of_appetite: 0.75, sweating: 0.60, dizziness: 0.20,
      rash: 0.05, joint_pain: 0.15, abdominal_pain: 0.10, back_pain: 0.20,
      swollen_lymph_nodes: 0.55, frequent_urination: 0.02, blurred_vision: 0.02,
      numbness: 0.02, weight_loss: 0.80, night_sweats: 0.85, sneezing: 0.05,
      itching: 0.02, palpitations: 0.10, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Diabetes": 1.8, "HIV/AIDS": 3.0, "Immunocompromised": 2.5, "Malnutrition": 2.0
    }
  },
  {
    name: "Dengue Fever",
    prior: 0.02,
    description: "A mosquito-borne viral disease causing severe flu-like symptoms and potentially life-threatening complications.",
    see_doctor_if: "Go to the ER immediately if you have severe abdominal pain, persistent vomiting, bleeding, or rapid breathing.",
    danger_level: "high",
    emergency_symptoms: ["fever", "rash", "joint_pain"],
    key_symptoms: ["fever", "body_aches", "rash", "headache", "joint_pain"],
    age_mean: 25,
    age_std: 15,
    symptoms: {
      fever: 0.95, cough: 0.20, fatigue: 0.85, difficulty_breathing: 0.15,
      headache: 0.85, nausea: 0.55, vomiting: 0.45, diarrhea: 0.25,
      chest_pain: 0.10, sore_throat: 0.10, runny_nose: 0.10, body_aches: 0.90,
      chills: 0.55, loss_of_appetite: 0.70, sweating: 0.50, dizziness: 0.40,
      rash: 0.65, joint_pain: 0.85, abdominal_pain: 0.40, back_pain: 0.50,
      swollen_lymph_nodes: 0.20, frequent_urination: 0.02, blurred_vision: 0.05,
      numbness: 0.05, weight_loss: 0.15, night_sweats: 0.30, sneezing: 0.05,
      itching: 0.30, palpitations: 0.10, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.3, "Normal": 1.0, "Elevated": 0.9, "High": 0.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Diabetes": 1.4, "Heart Disease": 1.3
    }
  },
  {
    name: "Malaria",
    prior: 0.02,
    description: "A life-threatening parasitic disease transmitted by mosquitoes, causing cyclical fever and chills.",
    see_doctor_if: "Seek emergency care immediately if you have high fever, confusion, seizures, or difficulty breathing.",
    danger_level: "critical",
    emergency_symptoms: ["fever", "chills", "dizziness"],
    key_symptoms: ["fever", "chills", "sweating", "headache", "fatigue"],
    age_mean: 20,
    age_std: 15,
    symptoms: {
      fever: 0.97, cough: 0.20, fatigue: 0.90, difficulty_breathing: 0.25,
      headache: 0.85, nausea: 0.70, vomiting: 0.60, diarrhea: 0.30,
      chest_pain: 0.10, sore_throat: 0.05, runny_nose: 0.05, body_aches: 0.80,
      chills: 0.92, loss_of_appetite: 0.75, sweating: 0.88, dizziness: 0.50,
      rash: 0.08, joint_pain: 0.40, abdominal_pain: 0.45, back_pain: 0.30,
      swollen_lymph_nodes: 0.15, frequent_urination: 0.02, blurred_vision: 0.10,
      numbness: 0.05, weight_loss: 0.30, night_sweats: 0.70, sneezing: 0.02,
      itching: 0.05, palpitations: 0.15, loss_of_taste_smell: 0.03
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.2, "Normal": 1.0, "Elevated": 0.9, "High": 0.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Anemia": 1.5, "Sickle Cell": 1.3, "Immunocompromised": 1.8
    }
  },
  {
    name: "Typhoid Fever",
    prior: 0.02,
    description: "A bacterial infection caused by Salmonella typhi, spread through contaminated food and water.",
    see_doctor_if: "Seek immediate care if you develop confusion, severe abdominal pain, or the fever doesn't respond to treatment.",
    danger_level: "high",
    emergency_symptoms: ["fever", "abdominal_pain"],
    key_symptoms: ["fever", "abdominal_pain", "headache", "fatigue", "loss_of_appetite"],
    age_mean: 20,
    age_std: 12,
    symptoms: {
      fever: 0.95, cough: 0.25, fatigue: 0.88, difficulty_breathing: 0.10,
      headache: 0.80, nausea: 0.60, vomiting: 0.40, diarrhea: 0.45,
      chest_pain: 0.05, sore_throat: 0.15, runny_nose: 0.10, body_aches: 0.70,
      chills: 0.55, loss_of_appetite: 0.80, sweating: 0.55, dizziness: 0.35,
      rash: 0.30, joint_pain: 0.20, abdominal_pain: 0.75, back_pain: 0.25,
      swollen_lymph_nodes: 0.15, frequent_urination: 0.03, blurred_vision: 0.05,
      numbness: 0.03, weight_loss: 0.50, night_sweats: 0.50, sneezing: 0.05,
      itching: 0.05, palpitations: 0.10, loss_of_taste_smell: 0.10
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.2, "Normal": 1.0, "Elevated": 0.9, "High": 0.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Immunocompromised": 2.0, "Malnutrition": 1.6
    }
  },
  {
    name: "Gastroenteritis",
    prior: 0.06,
    description: "Inflammation of the stomach and intestines, typically caused by viral or bacterial infection.",
    see_doctor_if: "See a doctor if you cannot keep fluids down for 24 hours, see blood in stool, or show signs of severe dehydration.",
    danger_level: "medium",
    emergency_symptoms: ["vomiting", "diarrhea", "abdominal_pain"],
    key_symptoms: ["nausea", "vomiting", "diarrhea", "abdominal_pain", "fever"],
    age_mean: 20,
    age_std: 18,
    symptoms: {
      fever: 0.50, cough: 0.05, fatigue: 0.70, difficulty_breathing: 0.03,
      headache: 0.45, nausea: 0.90, vomiting: 0.80, diarrhea: 0.85,
      chest_pain: 0.02, sore_throat: 0.05, runny_nose: 0.05, body_aches: 0.55,
      chills: 0.40, loss_of_appetite: 0.80, sweating: 0.30, dizziness: 0.40,
      rash: 0.02, joint_pain: 0.05, abdominal_pain: 0.85, back_pain: 0.15,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.05, blurred_vision: 0.03,
      numbness: 0.02, weight_loss: 0.25, night_sweats: 0.15, sneezing: 0.05,
      itching: 0.02, palpitations: 0.08, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.2, "Normal": 1.0, "Elevated": 0.9, "High": 0.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Immunocompromised": 1.6, "Inflammatory Bowel Disease": 1.4
    }
  },
  {
    name: "Ulcerative Colitis",
    prior: 0.02,
    description: "A chronic inflammatory bowel disease causing inflammation and ulcers in the colon and rectum.",
    see_doctor_if: "Seek urgent care if you have severe abdominal pain, significant rectal bleeding, or signs of dehydration.",
    danger_level: "medium",
    emergency_symptoms: ["abdominal_pain", "diarrhea"],
    key_symptoms: ["diarrhea", "abdominal_pain", "weight_loss", "fatigue", "nausea"],
    age_mean: 35,
    age_std: 15,
    symptoms: {
      fever: 0.35, cough: 0.03, fatigue: 0.75, difficulty_breathing: 0.02,
      headache: 0.20, nausea: 0.55, vomiting: 0.25, diarrhea: 0.90,
      chest_pain: 0.02, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.30,
      chills: 0.20, loss_of_appetite: 0.65, sweating: 0.20, dizziness: 0.30,
      rash: 0.10, joint_pain: 0.35, abdominal_pain: 0.85, back_pain: 0.20,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.05, blurred_vision: 0.03,
      numbness: 0.03, weight_loss: 0.60, night_sweats: 0.20, sneezing: 0.02,
      itching: 0.10, palpitations: 0.10, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Crohn's Disease": 1.2, "Autoimmune Disorder": 1.4
    }
  },
  {
    name: "Crohn's Disease",
    prior: 0.02,
    description: "A chronic inflammatory bowel disease that can affect any part of the digestive tract.",
    see_doctor_if: "Seek urgent care if you have severe abdominal pain, high fever, significant rectal bleeding, or intestinal obstruction symptoms.",
    danger_level: "medium",
    emergency_symptoms: ["abdominal_pain", "diarrhea", "fever"],
    key_symptoms: ["abdominal_pain", "diarrhea", "weight_loss", "fatigue", "nausea"],
    age_mean: 30,
    age_std: 12,
    symptoms: {
      fever: 0.40, cough: 0.03, fatigue: 0.80, difficulty_breathing: 0.02,
      headache: 0.20, nausea: 0.60, vomiting: 0.30, diarrhea: 0.85,
      chest_pain: 0.02, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.35,
      chills: 0.20, loss_of_appetite: 0.70, sweating: 0.20, dizziness: 0.25,
      rash: 0.10, joint_pain: 0.40, abdominal_pain: 0.90, back_pain: 0.25,
      swollen_lymph_nodes: 0.10, frequent_urination: 0.05, blurred_vision: 0.03,
      numbness: 0.03, weight_loss: 0.70, night_sweats: 0.25, sneezing: 0.02,
      itching: 0.10, palpitations: 0.10, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Ulcerative Colitis": 1.2, "Autoimmune Disorder": 1.4
    }
  },
  {
    name: "Pancreatitis",
    prior: 0.015,
    description: "Inflammation of the pancreas causing severe abdominal pain that may radiate to the back.",
    see_doctor_if: "Go to the ER immediately if you have severe upper abdominal pain, especially if it radiates to your back with fever.",
    danger_level: "critical",
    emergency_symptoms: ["abdominal_pain", "vomiting", "fever"],
    key_symptoms: ["abdominal_pain", "nausea", "vomiting", "fever", "back_pain"],
    age_mean: 45,
    age_std: 15,
    symptoms: {
      fever: 0.55, cough: 0.05, fatigue: 0.75, difficulty_breathing: 0.20,
      headache: 0.25, nausea: 0.85, vomiting: 0.80, diarrhea: 0.30,
      chest_pain: 0.15, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.50,
      chills: 0.40, loss_of_appetite: 0.85, sweating: 0.45, dizziness: 0.40,
      rash: 0.05, joint_pain: 0.10, abdominal_pain: 0.95, back_pain: 0.65,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.03, blurred_vision: 0.05,
      numbness: 0.03, weight_loss: 0.40, night_sweats: 0.20, sneezing: 0.02,
      itching: 0.10, palpitations: 0.15, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.2, "Normal": 1.0, "Elevated": 0.9, "High": 0.9 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.3, "High": 1.6 },
    preexisting_modifiers: {
      "Diabetes": 1.4, "Gallstones": 2.0, "Alcoholism": 2.5
    }
  },
  {
    name: "Liver Disease",
    prior: 0.02,
    description: "Damage or dysfunction of the liver, encompassing conditions like hepatitis, cirrhosis, and fatty liver disease.",
    see_doctor_if: "Seek immediate care if you develop jaundice, severe abdominal swelling, confusion, or vomit blood.",
    danger_level: "high",
    emergency_symptoms: ["abdominal_pain", "nausea", "fatigue"],
    key_symptoms: ["fatigue", "nausea", "abdominal_pain", "weight_loss", "itching"],
    age_mean: 50,
    age_std: 18,
    symptoms: {
      fever: 0.30, cough: 0.05, fatigue: 0.85, difficulty_breathing: 0.10,
      headache: 0.20, nausea: 0.70, vomiting: 0.40, diarrhea: 0.25,
      chest_pain: 0.05, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.40,
      chills: 0.20, loss_of_appetite: 0.80, sweating: 0.25, dizziness: 0.30,
      rash: 0.15, joint_pain: 0.25, abdominal_pain: 0.70, back_pain: 0.20,
      swollen_lymph_nodes: 0.20, frequent_urination: 0.05, blurred_vision: 0.08,
      numbness: 0.10, weight_loss: 0.65, night_sweats: 0.30, sneezing: 0.02,
      itching: 0.55, palpitations: 0.10, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 0.9, "High": 0.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.2, "Normal": 1.0, "Elevated": 1.2, "High": 1.4 },
    preexisting_modifiers: {
      "Diabetes": 1.5, "Obesity": 1.6, "Alcoholism": 2.5, "Hepatitis B": 2.0, "Hepatitis C": 2.0
    }
  },
  {
    name: "Kidney Disease",
    prior: 0.02,
    description: "Progressive loss of kidney function, affecting the body's ability to filter waste from the blood.",
    see_doctor_if: "Seek immediate care if you have sudden decrease in urine output, severe swelling, shortness of breath, or chest pain.",
    danger_level: "high",
    emergency_symptoms: ["back_pain", "frequent_urination", "swollen_lymph_nodes"],
    key_symptoms: ["fatigue", "frequent_urination", "back_pain", "swollen_lymph_nodes", "dizziness"],
    age_mean: 60,
    age_std: 18,
    symptoms: {
      fever: 0.20, cough: 0.10, fatigue: 0.85, difficulty_breathing: 0.30,
      headache: 0.40, nausea: 0.60, vomiting: 0.35, diarrhea: 0.15,
      chest_pain: 0.15, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.40,
      chills: 0.15, loss_of_appetite: 0.65, sweating: 0.20, dizziness: 0.45,
      rash: 0.15, joint_pain: 0.25, abdominal_pain: 0.30, back_pain: 0.60,
      swollen_lymph_nodes: 0.15, frequent_urination: 0.75, blurred_vision: 0.20,
      numbness: 0.30, weight_loss: 0.40, night_sweats: 0.20, sneezing: 0.02,
      itching: 0.50, palpitations: 0.25, loss_of_taste_smell: 0.10
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.8, "Normal": 0.9, "Elevated": 1.3, "High": 1.8 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.2, "High": 1.4 },
    preexisting_modifiers: {
      "Diabetes": 2.0, "Hypertension": 1.8, "Heart Disease": 1.4
    }
  },
  {
    name: "Diabetes",
    prior: 0.04,
    description: "A metabolic disease causing high blood sugar due to insufficient insulin production or resistance.",
    see_doctor_if: "Seek emergency care if you experience extreme thirst with confusion, rapid breathing, or loss of consciousness.",
    danger_level: "high",
    emergency_symptoms: ["frequent_urination", "blurred_vision", "weight_loss"],
    key_symptoms: ["frequent_urination", "fatigue", "blurred_vision", "weight_loss", "numbness"],
    age_mean: 55,
    age_std: 18,
    symptoms: {
      fever: 0.05, cough: 0.05, fatigue: 0.80, difficulty_breathing: 0.10,
      headache: 0.35, nausea: 0.25, vomiting: 0.10, diarrhea: 0.10,
      chest_pain: 0.10, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.25,
      chills: 0.05, loss_of_appetite: 0.15, sweating: 0.30, dizziness: 0.30,
      rash: 0.10, joint_pain: 0.15, abdominal_pain: 0.15, back_pain: 0.15,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.85, blurred_vision: 0.55,
      numbness: 0.55, weight_loss: 0.60, night_sweats: 0.15, sneezing: 0.02,
      itching: 0.40, palpitations: 0.15, loss_of_taste_smell: 0.05
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.8, "Normal": 0.9, "Elevated": 1.3, "High": 1.6 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.3, "High": 1.6 },
    preexisting_modifiers: {
      "Obesity": 2.0, "Hypertension": 1.4, "Heart Disease": 1.3, "Kidney Disease": 1.5
    }
  },
  {
    name: "Hypertension",
    prior: 0.04,
    description: "Persistently elevated blood pressure that increases risk of heart disease, stroke, and kidney damage.",
    see_doctor_if: "Seek emergency care immediately if blood pressure exceeds 180/120 with headache, vision changes, or chest pain.",
    danger_level: "high",
    emergency_symptoms: ["headache", "chest_pain", "dizziness"],
    key_symptoms: ["headache", "dizziness", "chest_pain", "blurred_vision", "palpitations"],
    age_mean: 55,
    age_std: 18,
    symptoms: {
      fever: 0.03, cough: 0.05, fatigue: 0.50, difficulty_breathing: 0.25,
      headache: 0.65, nausea: 0.25, vomiting: 0.10, diarrhea: 0.03,
      chest_pain: 0.30, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.15,
      chills: 0.03, loss_of_appetite: 0.10, sweating: 0.20, dizziness: 0.50,
      rash: 0.02, joint_pain: 0.10, abdominal_pain: 0.10, back_pain: 0.15,
      swollen_lymph_nodes: 0.02, frequent_urination: 0.10, blurred_vision: 0.35,
      numbness: 0.15, weight_loss: 0.05, night_sweats: 0.10, sneezing: 0.02,
      itching: 0.02, palpitations: 0.40, loss_of_taste_smell: 0.03
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.1, "Normal": 0.3, "Elevated": 1.5, "High": 3.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.2, "High": 1.4 },
    preexisting_modifiers: {
      "Diabetes": 1.5, "Obesity": 1.6, "Kidney Disease": 1.5, "Heart Disease": 1.4
    }
  },
  {
    name: "Stroke",
    prior: 0.01,
    description: "A medical emergency where blood supply to the brain is interrupted, causing brain cell death.",
    see_doctor_if: "Call 911 immediately — stroke is a life-threatening emergency requiring treatment within hours.",
    danger_level: "critical",
    emergency_symptoms: ["numbness", "blurred_vision", "headache", "dizziness"],
    key_symptoms: ["numbness", "headache", "blurred_vision", "dizziness", "difficulty_breathing"],
    age_mean: 65,
    age_std: 15,
    symptoms: {
      fever: 0.05, cough: 0.05, fatigue: 0.60, difficulty_breathing: 0.30,
      headache: 0.75, nausea: 0.40, vomiting: 0.30, diarrhea: 0.03,
      chest_pain: 0.20, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.25,
      chills: 0.05, loss_of_appetite: 0.30, sweating: 0.20, dizziness: 0.65,
      rash: 0.02, joint_pain: 0.05, abdominal_pain: 0.05, back_pain: 0.10,
      swollen_lymph_nodes: 0.02, frequent_urination: 0.05, blurred_vision: 0.70,
      numbness: 0.80, weight_loss: 0.10, night_sweats: 0.05, sneezing: 0.02,
      itching: 0.02, palpitations: 0.30, loss_of_taste_smell: 0.20
    },
    bp_modifier: { "Unknown": 1.0, "Low": 0.5, "Normal": 0.6, "Elevated": 1.5, "High": 2.5 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.3, "High": 1.6 },
    preexisting_modifiers: {
      "Hypertension": 2.5, "Diabetes": 1.8, "Heart Disease": 2.0, "Atrial Fibrillation": 3.0
    }
  },
  {
    name: "Migraine",
    prior: 0.04,
    description: "A neurological condition causing severe recurring headaches, often with nausea, vomiting, and sensitivity to light.",
    see_doctor_if: "Seek emergency care if headache is sudden and severe ('thunderclap'), or accompanied by fever, stiff neck, or neurological symptoms.",
    danger_level: "medium",
    emergency_symptoms: ["headache", "blurred_vision"],
    key_symptoms: ["headache", "nausea", "blurred_vision", "dizziness", "vomiting"],
    age_mean: 35,
    age_std: 15,
    symptoms: {
      fever: 0.05, cough: 0.03, fatigue: 0.65, difficulty_breathing: 0.05,
      headache: 0.97, nausea: 0.80, vomiting: 0.55, diarrhea: 0.05,
      chest_pain: 0.03, sore_throat: 0.03, runny_nose: 0.10, body_aches: 0.30,
      chills: 0.10, loss_of_appetite: 0.55, sweating: 0.20, dizziness: 0.60,
      rash: 0.02, joint_pain: 0.10, abdominal_pain: 0.20, back_pain: 0.15,
      swollen_lymph_nodes: 0.02, frequent_urination: 0.05, blurred_vision: 0.55,
      numbness: 0.25, weight_loss: 0.05, night_sweats: 0.05, sneezing: 0.05,
      itching: 0.02, palpitations: 0.10, loss_of_taste_smell: 0.20
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.1, "High": 1.2 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Hypertension": 1.3, "Anxiety": 1.3, "Depression": 1.2
    }
  },
  {
    name: "Rheumatoid Arthritis",
    prior: 0.02,
    description: "An autoimmune disease causing chronic inflammation of the joints, leading to pain, swelling, and eventual joint damage.",
    see_doctor_if: "See a doctor promptly if you experience sudden severe joint pain, warmth and redness in multiple joints, or morning stiffness lasting hours.",
    danger_level: "medium",
    emergency_symptoms: ["joint_pain", "swollen_lymph_nodes"],
    key_symptoms: ["joint_pain", "fatigue", "body_aches", "swollen_lymph_nodes", "fever"],
    age_mean: 50,
    age_std: 18,
    symptoms: {
      fever: 0.35, cough: 0.05, fatigue: 0.80, difficulty_breathing: 0.10,
      headache: 0.25, nausea: 0.20, vomiting: 0.08, diarrhea: 0.08,
      chest_pain: 0.10, sore_throat: 0.05, runny_nose: 0.05, body_aches: 0.75,
      chills: 0.25, loss_of_appetite: 0.50, sweating: 0.25, dizziness: 0.20,
      rash: 0.15, joint_pain: 0.92, abdominal_pain: 0.15, back_pain: 0.40,
      swollen_lymph_nodes: 0.30, frequent_urination: 0.03, blurred_vision: 0.08,
      numbness: 0.20, weight_loss: 0.35, night_sweats: 0.25, sneezing: 0.03,
      itching: 0.05, palpitations: 0.10, loss_of_taste_smell: 0.03
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.1, "High": 1.2 },
    preexisting_modifiers: {
      "Autoimmune Disorder": 1.8, "Smoking": 1.5, "Family History": 1.5
    }
  },
  {
    name: "Osteoarthritis",
    prior: 0.03,
    description: "Degenerative joint disease causing cartilage breakdown, resulting in pain, stiffness, and reduced range of motion.",
    see_doctor_if: "See a doctor if joint pain is severe, sudden, or accompanied by significant swelling, warmth, or redness.",
    danger_level: "low",
    emergency_symptoms: ["joint_pain"],
    key_symptoms: ["joint_pain", "back_pain", "body_aches", "fatigue", "dizziness"],
    age_mean: 65,
    age_std: 12,
    symptoms: {
      fever: 0.03, cough: 0.03, fatigue: 0.55, difficulty_breathing: 0.05,
      headache: 0.15, nausea: 0.10, vomiting: 0.05, diarrhea: 0.03,
      chest_pain: 0.05, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.65,
      chills: 0.05, loss_of_appetite: 0.25, sweating: 0.10, dizziness: 0.20,
      rash: 0.02, joint_pain: 0.90, abdominal_pain: 0.05, back_pain: 0.70,
      swollen_lymph_nodes: 0.05, frequent_urination: 0.05, blurred_vision: 0.05,
      numbness: 0.15, weight_loss: 0.10, night_sweats: 0.05, sneezing: 0.02,
      itching: 0.02, palpitations: 0.05, loss_of_taste_smell: 0.02
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Obesity": 1.6, "Diabetes": 1.2, "Previous Joint Injury": 1.8
    }
  },
  {
    name: "Osteoporosis",
    prior: 0.02,
    description: "A condition where bones become weak and brittle due to decreased bone density, increasing fracture risk.",
    see_doctor_if: "See a doctor if you experience sudden back pain, significant height loss, or any fracture from a minor fall.",
    danger_level: "medium",
    emergency_symptoms: ["back_pain"],
    key_symptoms: ["back_pain", "joint_pain", "body_aches", "fatigue", "weight_loss"],
    age_mean: 68,
    age_std: 12,
    symptoms: {
      fever: 0.02, cough: 0.03, fatigue: 0.50, difficulty_breathing: 0.05,
      headache: 0.10, nausea: 0.08, vomiting: 0.03, diarrhea: 0.03,
      chest_pain: 0.10, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.55,
      chills: 0.03, loss_of_appetite: 0.15, sweating: 0.08, dizziness: 0.15,
      rash: 0.02, joint_pain: 0.55, abdominal_pain: 0.05, back_pain: 0.80,
      swollen_lymph_nodes: 0.02, frequent_urination: 0.03, blurred_vision: 0.05,
      numbness: 0.10, weight_loss: 0.15, night_sweats: 0.05, sneezing: 0.02,
      itching: 0.02, palpitations: 0.03, loss_of_taste_smell: 0.02
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.1, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Menopause": 2.0, "Smoking": 1.4, "Corticosteroid Use": 1.7, "Calcium Deficiency": 1.5
    }
  },
  {
    name: "Eczema",
    prior: 0.03,
    description: "A chronic inflammatory skin condition causing dry, itchy, inflamed patches of skin.",
    see_doctor_if: "See a doctor if skin becomes infected, oozes fluid or pus, or if the rash spreads rapidly and severely.",
    danger_level: "low",
    emergency_symptoms: ["rash", "itching"],
    key_symptoms: ["itching", "rash", "fatigue"],
    age_mean: 15,
    age_std: 15,
    symptoms: {
      fever: 0.05, cough: 0.05, fatigue: 0.40, difficulty_breathing: 0.05,
      headache: 0.15, nausea: 0.05, vomiting: 0.02, diarrhea: 0.03,
      chest_pain: 0.02, sore_throat: 0.05, runny_nose: 0.15, body_aches: 0.10,
      chills: 0.03, loss_of_appetite: 0.15, sweating: 0.10, dizziness: 0.05,
      rash: 0.90, joint_pain: 0.05, abdominal_pain: 0.03, back_pain: 0.05,
      swollen_lymph_nodes: 0.10, frequent_urination: 0.01, blurred_vision: 0.02,
      numbness: 0.02, weight_loss: 0.03, night_sweats: 0.05, sneezing: 0.15,
      itching: 0.92, palpitations: 0.02, loss_of_taste_smell: 0.02
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Allergic Rhinitis": 1.6, "Asthma": 1.4, "Autoimmune Disorder": 1.3
    }
  },
  {
    name: "Psoriasis",
    prior: 0.02,
    description: "A chronic autoimmune condition causing rapid skin cell buildup, resulting in scaling, redness, and inflammation.",
    see_doctor_if: "See a doctor if psoriasis covers large areas of the body, is severely painful, or accompanied by joint pain.",
    danger_level: "low",
    emergency_symptoms: ["rash"],
    key_symptoms: ["rash", "itching", "joint_pain", "fatigue"],
    age_mean: 35,
    age_std: 18,
    symptoms: {
      fever: 0.05, cough: 0.03, fatigue: 0.45, difficulty_breathing: 0.03,
      headache: 0.15, nausea: 0.08, vomiting: 0.03, diarrhea: 0.03,
      chest_pain: 0.03, sore_throat: 0.03, runny_nose: 0.05, body_aches: 0.20,
      chills: 0.05, loss_of_appetite: 0.15, sweating: 0.08, dizziness: 0.05,
      rash: 0.92, joint_pain: 0.45, abdominal_pain: 0.05, back_pain: 0.20,
      swollen_lymph_nodes: 0.08, frequent_urination: 0.02, blurred_vision: 0.03,
      numbness: 0.05, weight_loss: 0.10, night_sweats: 0.08, sneezing: 0.05,
      itching: 0.80, palpitations: 0.05, loss_of_taste_smell: 0.02
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.1, "High": 1.2 },
    preexisting_modifiers: {
      "Autoimmune Disorder": 1.8, "Stress": 1.3, "Obesity": 1.3
    }
  },
  {
    name: "Urinary Tract Infection",
    prior: 0.04,
    description: "A bacterial infection affecting the urinary system, most commonly the bladder and urethra.",
    see_doctor_if: "Seek immediate care if you have high fever, back or flank pain, chills, or vomiting alongside urinary symptoms.",
    danger_level: "medium",
    emergency_symptoms: ["frequent_urination", "back_pain", "fever"],
    key_symptoms: ["frequent_urination", "abdominal_pain", "back_pain", "fever", "fatigue"],
    age_mean: 35,
    age_std: 20,
    symptoms: {
      fever: 0.50, cough: 0.03, fatigue: 0.65, difficulty_breathing: 0.03,
      headache: 0.30, nausea: 0.45, vomiting: 0.25, diarrhea: 0.10,
      chest_pain: 0.02, sore_throat: 0.02, runny_nose: 0.02, body_aches: 0.40,
      chills: 0.40, loss_of_appetite: 0.40, sweating: 0.25, dizziness: 0.25,
      rash: 0.02, joint_pain: 0.05, abdominal_pain: 0.70, back_pain: 0.65,
      swollen_lymph_nodes: 0.10, frequent_urination: 0.90, blurred_vision: 0.03,
      numbness: 0.02, weight_loss: 0.05, night_sweats: 0.15, sneezing: 0.02,
      itching: 0.30, palpitations: 0.05, loss_of_taste_smell: 0.02
    },
    bp_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.1 },
    cholesterol_modifier: { "Unknown": 1.0, "Low": 1.0, "Normal": 1.0, "Elevated": 1.0, "High": 1.0 },
    preexisting_modifiers: {
      "Diabetes": 1.7, "Kidney Disease": 1.5, "Immunocompromised": 1.6
    }
  }
];
